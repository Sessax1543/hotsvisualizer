IN ORDER TO RUN THE .EXE YOU NEED TO HAVE => .NET Desktop Runtime 3.1

YOU CAN DOWNLOAD IT HERE:
https://dotnet.microsoft.com/en-us/download/dotnet/3.1

TO RUN THE PARTSER, EXTRACT parser FOLDER AND RUN MatchParserApplication.exe

ENJOY! :)